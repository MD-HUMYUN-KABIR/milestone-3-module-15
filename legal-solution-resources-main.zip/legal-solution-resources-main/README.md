# Legal Solutions Resources

### Click Here to create [private repo](https://classroom.github.com/a/Zkz-U3QK)
Private Repo link: [https://classroom.github.com/a/Zkz-U3QK](https://classroom.github.com/a/Zkz-U3QK)


----------------
If needed rename the images to give them some meaningful name. Please note, renmaing images is optional. 
